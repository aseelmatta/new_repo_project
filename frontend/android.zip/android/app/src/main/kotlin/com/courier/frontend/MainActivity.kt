package com.courier.frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
